# Render Deployment Version

## Deploy on Render
1. Upload repository to GitHub
2. On Render → New → Worker
3. Build Command:
   `pip install -r requirements.txt`
4. Start Command:
   `python bot.py`
5. Add environment variables if needed.

Make sure `sessions/` folder exists — Telethon stores session files there.
